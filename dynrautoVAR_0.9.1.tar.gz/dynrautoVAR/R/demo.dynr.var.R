#' Demo Output of dynr.var()
#'
#' @format A list of length ten. Each element of the list has the followin elemens
#'   \describe{
#'     \item{Betas}{Maybe we can put a description here.}
#'     \item{ResidCov}{Maybe we can put a description here.}
#'     \item{PCC}{Maybe we can put a description here.}
#'     \item{PDC}{Maybe we can put a description here.}
#'     \item{Res}{Maybe we can put a description here.}
#'   }
#' @keywords data
"demo.dynr.var"
