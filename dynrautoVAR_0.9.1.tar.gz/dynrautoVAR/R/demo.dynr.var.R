#' Demo Output of dynr.var() using demo.dat
#'
#' @format A list of length ten. Each element of the list has the following elements
#'   \describe{
#'     \item{Betas}{Maybe we can put a description here.}
#'     \item{ResidCov}{Maybe we can put a description here.}
#'     \item{PCC}{Maybe we can put a description here.}
#'     \item{PDC}{Maybe we can put a description here.}
#'     \item{Res}{Maybe we can put a description here.}
#'   }
#' @keywords data
"demo.dynr.var"
