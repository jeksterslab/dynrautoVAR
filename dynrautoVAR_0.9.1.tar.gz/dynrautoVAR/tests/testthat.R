library(testthat)
library(dynrautoVAR)

test_check("dynrautoVAR")
